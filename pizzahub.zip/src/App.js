
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './component/Header';
import Home from './component/Home';
import Footer from './component/Footer';
import About from './component/About';
import Service from './component/Service';
import Blog from './component/Blog';
import Contact from './component/Contact';
import Login from './component/Login';
import Signup from './component/Signup';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function App() {
  return (
    <BrowserRouter>
      <ToastContainer />
      <Routes>
        <Route index path='/' element={<><Header /><Home /><Footer /></>}></Route>
        <Route path='/about' element={<><Header /><About /><Footer /></>}></Route>
        <Route path='/service' element={<><Header /><Service /><Footer /></>}></Route>
        <Route path='/blog' element={<><Header /><Blog /><Footer /></>}></Route>
        <Route path='/contact' element={<><Header /><Contact /><Footer /></>}></Route>
        <Route path='/login' element={<><Header /><Login /><Footer /></>}></Route>
        <Route path='/signup' element={<><Header /><Signup /><Footer /></>}></Route>
      </Routes>


    </BrowserRouter>
  );
}

export default App;
