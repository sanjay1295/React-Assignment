import React from 'react';
import { NavLink } from 'react-router-dom';

function Header() {
    return (
        <div className="main-layout">
            <div className="full_bg">
                {/* header */}
                <header className="header-area">
                    <div className="container">
                        <div className="row d_flex">
                            <div className=" col-md-3 col-sm-3">
                                <div className="logo">
                                    <NavLink to="/">Bliss</NavLink>
                                </div>
                            </div>
                            <div className="col-md-9 col-sm-9">
                                <div className="navbar-area">
                                    <nav className="site-navbar">
                                        <ul>
                                            <li><NavLink className="active" to="/">Home</NavLink></li>
                                            <li><NavLink to="/about">About</NavLink></li>
                                            <li><NavLink to="/service">Service</NavLink></li>
                                            <li><NavLink to="/blog">Blog</NavLink></li>
                                            <li><NavLink to="/contact">Contact us</NavLink></li>
                                            <li><NavLink to="/login">Login</NavLink></li>
                                            {/* <li className="d_none"><a href="Javascript:void(0)"><i className="fa fa-user" aria-hidden="true" /></a></li> */}
                                            <li className="d_none"><a href="Javascript:void(0)"><i className="fa fa-search" aria-hidden="true" /></a></li>
                                        </ul>
                                        <button className="nav-toggler">
                                            <span />
                                        </button>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
                {/* end header inner */}
            </div>


        </div>
    );
}

export default Header;
