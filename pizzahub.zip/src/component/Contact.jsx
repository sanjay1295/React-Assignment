import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

function Contact() {

    const [formvalue, setFormvalue] = useState({
        id: "",
        name: "",
        email: "",
        mobile: "",
        message: ""
    })
    const onchange = (e) => {
        setFormvalue({ ...formvalue, id: new Date().getTime().toString(), [e.target.name]: e.target.value });
        // console.log(formvalue)
    }

    const validation = () => {
        let result = true;
        if (formvalue.name === "" || formvalue.name === null) {
            result = false;
            toast.error('Name field is required !');
            return false;
        }
        if (formvalue.email === "" || formvalue.email === null) {
            result = false;
            toast.error('Email field is required !');
            return false;
        }
        if (formvalue.mobile === "" || formvalue.mobile === null) {
            result = false;
            toast.error('Mobile field is required !');
            return false;
        }
        if (formvalue.message === "" || formvalue.message === null) {
            result = false;
            toast.error('Message field is required !');
            return false;
        }
        return result;
    }

    const onsubmit = async (e) => {
        e.preventDefault();
        if (validation()) {
            await axios.post('http://localhost:3000/contact', formvalue)
                .then((res) => {
                    if (res.status === 201) {
                        toast.success('Done', {
                            position: toast.POSITION.TOP_CENTER
                        }
                        );
                        setFormvalue({ ...formvalue, name: "", email: "", mobile: "", message: "" })
                    }
                })
        }
    }
    return (
        <div>
            {/* appointment */}
            <div className="appointment">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 ">
                            <div className="titlepage text_align_center">
                                <h2>Contact Us</h2>
                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu</p>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <form id="request" className="main_form">
                                <div className="row">
                                    <div className="col-md-6 ">
                                        <input className="form_control" value={formvalue.name} onChange={onchange} placeholder="Your name" type="text" name="name" />
                                    </div>
                                    <div className="col-md-6">
                                        <input className="form_control" value={formvalue.email} onChange={onchange} placeholder="Email" type="text" name="email" />
                                    </div>
                                    <div className="col-md-6">
                                        <input className="form_control" value={formvalue.mobile} onChange={onchange} placeholder="Phone Number" type="number" name="mobile" />
                                    </div>
                                    <div className="col-md-12">
                                        <textarea style={{ color: '#d0d0cf' }} value={formvalue.message} onChange={onchange} className="textarea" placeholder="Message" type="textarea" name="message" />
                                    </div>
                                    <div className="col-md-12">
                                        <button className="send_btn" onClick={onsubmit}>Send Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            {/* end appointment */}


        </div>
    );
}

export default Contact;
