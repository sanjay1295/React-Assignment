import React from 'react';
import { NavLink } from 'react-router-dom';

function Login() {
    return (
        <div>
            <div className="appointment">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 ">
                            <div className="titlepage text_align_center">
                                <h2>LOGIN DETAILS</h2>
                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu</p>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <form id="request" className="main_form ">
                                
                                    <div className="col-md-6 row d-block m-auto">
                                        <input className="form_control" placeholder="Email / Phone Number" type="type" name="Email" />
                                    </div>
                                    <div className="col-md-6 row d-block m-auto">
                                    <input className="form_control" placeholder="Password" type="password" name="Password" />
                                    </div>
                                    <div className="col-md-12">
                                        <button className="send_btn">Submit</button>    
                                    </div>
                                    <div className="col-md-3 d-block m-auto">
                                    <p className="mt-5">Not a member?... <span>   </span><NavLink  to="/signup" style={{color:'red'}}>SignUp now</NavLink></p>
                                    </div>

                               
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Login;
