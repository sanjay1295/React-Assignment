import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
function Signup() {

    const [formvalue, setFormvalue] = useState({
        id: "",
        fname: "",
        lname: "",
        email: "",
        password: "",
        status: ""
    })
    const onchange = (e) => {
        setFormvalue({ ...formvalue, id: new Date().getTime().toString(),status:"unblock", [e.target.name]: e.target.value });
        console.log(formvalue)
    }

    const validation =()=>{
        let result =true;
        if(formvalue.fname ==="" || formvalue.fname === null){
            result = false;
            toast.error('First Name field is required !');
            return false;
        }
        if(formvalue.lname ==="" || formvalue.lname === null){
            result = false;
            toast.error('Last Name field is required !');
            return false;
        }
        if(formvalue.email ==="" || formvalue.email === null){
            result = false;
            toast.error('Email field is required !');
            return false;
        }
        if(formvalue.password ==="" || formvalue.password === null){
            result = false;
            toast.error('Password field is required !');
            return false;
        }
        return result;
    }

    const onsubmit = async (e) => {
        e.preventDefault();
        if (validation()) {
            await axios.post('http://localhost:3000/user', formvalue)
            .then((res) => {
                if (res.status === 201) {
                    toast.success('Sign up Success', {
                        position: toast.POSITION.TOP_CENTER
                    }
                    );
                    setFormvalue({...formvalue,fname:"",lname:"",email:"",password:""})
                }
            })
        }
    }
    return (
        <div>
            <div className="appointment">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 ">
                            <div className="titlepage text_align_center">
                                <h2>SIGNUP DETAILS</h2>
                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu</p>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <form id="request" className="main_form ">
                                <div className="col-md-6 row d-block m-auto">
                                    <input className="form_control" value={formvalue.fname} onChange={onchange} placeholder="First Name" type="text" name="fname" />
                                </div>
                                <div className="col-md-6 row d-block m-auto">
                                    <input className="form_control" value={formvalue.lname} onChange={onchange} placeholder="Last Name" type="text" name="lname" />
                                </div>
                                <div className="col-md-6 row d-block m-auto">
                                    <input className="form_control" value={formvalue.email} onChange={onchange} placeholder="Email" type="email" name="email" />
                                </div>
                                <div className="col-md-6 row d-block m-auto">
                                    <input className="form_control" value={formvalue.password} onChange={onchange} placeholder="Password" type="password" name="password" />
                                </div>
                                <div className="col-md-12">
                                    <button className="send_btn" onClick={onsubmit}>Submit</button>
                                </div>
                                <div className="col-md-3 d-block m-auto">
                                    <p className="mt-5">Already a member?... <span>   </span><NavLink to="/login" style={{ color: 'red' }}>LogIn</NavLink></p>
                                </div>


                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Signup;
